package com.example.speedtest4;

public class Pokemon {
    private String name;
    private int image;
    private int attack;
    private int defence;
    private int total;

    public Pokemon(String name, int image, int attack, int defence, int total) {
        this.name = name;
        this.image = image;
        this.attack = attack;
        this.defence = defence;
        this.total = total;
    }
    public String getTitle() {
        return name;
    }

    public void setTitle(String title) {
        this.name = title;
    }

    public int getMainactor() {
        return image;
    }

    public void setMainactor(int mainactor) {
        this.image = mainactor;
    }

    public int getMovierate() {
        return attack;
    }

    public void setMovierate(int movierate) {
        this.attack = movierate;
    }

    public int getPgrate() {
        return defence;
    }

    public void setPgrate(int pngrate) {
        this.defence = pngrate;
    }

    public int getGenre() {
        return total;
    }

    public void setGenre(int genre) {
        this.total = genre;
    }
}



